# SkillUpParag website

A responsive static website built with HTML, CSS and vanilla JavaScript. It is ready to deploy on Netlify.

## Files
- `index.html` — landing page and service enquiry form
- `styles.css` — responsive styling
- `script.js` — mobile navigation and enquiry interactions
- `success.html` — post-submit confirmation page
- `assets/logo.svg` — SkillUpParag logo
- `assets/phonepe-payment-qr.jpg` — payment QR supplied by you
- `assets/parag-patil-resume.pdf` — resume supplied by you

## Deploy on Netlify
1. Extract `skilluparag-website.zip`.
2. Open Netlify and choose **Add new site → Deploy manually**.
3. Drag the extracted `skilluparag-website` folder (not the ZIP) into the deploy area.
4. After deployment, open **Site configuration → Notifications** (or **Forms** depending on the current Netlify UI) and configure a form submission email notification for `service-enquiry`, addressed to `paragpatil.rcpit@gmail.com`.
5. Submit a test enquiry from the live site and verify the notification arrives. Enable form detection and redeploy if Netlify asks you to.

## Important: enquiry form
The form uses Netlify Forms (`data-netlify="true"`). Netlify captures submissions after deployment. The HTML/JS alone cannot send email directly; configure the Netlify form email notification as described above. No email password or API key is exposed in the website.

## Before publishing
- Confirm that the payment QR is active and that the displayed recipient name is correct.
- Confirm the phone number, prices, social links and resume are current.
- Replace the resume PDF in `assets/` if you update your resume.
- Add your custom domain in Netlify if desired.
- The certificate/offer-letter wording is intentionally limited to genuine, verifiable course, internship and employment records. Do not issue documents that misrepresent a person's experience or employment.
