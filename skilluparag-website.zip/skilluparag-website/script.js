const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
if (menuButton && navLinks) {
  menuButton.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.textContent = isOpen ? "×" : "☰";
  });
  navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.textContent = "☰";
  }));
}
document.querySelectorAll("[data-service]").forEach(link => {
  link.addEventListener("click", () => {
    const select = document.querySelector("#service");
    if (select) {
      const name = link.dataset.service;
      const option = [...select.options].find(item => item.text.toLowerCase().startsWith(name.toLowerCase()));
      if (option) select.value = option.value;
    }
  });
});
const year = document.querySelector("#year");
if (year) year.textContent = new Date().getFullYear();


// Local form submission fix
const enquiryForm = document.querySelector(
  'form[name="service-enquiry"]'
);

if (enquiryForm) {
  enquiryForm.addEventListener("submit", function (event) {
    const isLocal =
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1" ||
      window.location.protocol === "file:";

    if (isLocal) {
      event.preventDefault();

      // Redirect to the success page for local preview
      window.location.href = "success.html";
    }
  });
}
